<?php class ControllerModuleLazadaImporter extends Controller
{
    private $error = array();

    public function index()
    {
        $data = $this->load->language('module/lazada_importer');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');
        /*save settings*/
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
//            echo '<pre>'; print_r($this->request->post); die;
            $this->model_setting_setting->editSetting('lazada_importer', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->cache->delete('lazada_importer');
            $this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'] . '&type=module', true));
        }

        $getConfigData = $this->model_setting_setting->getSetting('lazada_importer');

        foreach($getConfigData as $key => $configData){
            $data[$key] = $configData;
            if($key == 'lazada_importer_field_mapping'){
                foreach($configData as $index => $value){
                    $data['lazada_importer_field_mapping_'.$index] = $value;
                }
            }
        }
        unset($data['lazada_importer_field_mapping']);

        $data['heading_title'] = $this->language->get('heading_title');
        $data['lazada_importer_key'] = html_entity_decode($this->config->get('lazada_importer_key'));

        //breadcrumbs
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_module'),
            'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['action'] = $this->url->link('module/lazada_importer', 'token=' . $this->session->data['token'], 'SSL');

        $data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');
        $data['token'] = $this->session->data['token'];
        $lazada_importer_config = array(
            'status',
            'app_key',
            'app_name',
            'app_redirect_uri',
            'app_code',
            'app_secret',
            'tax_class_id',
            'available_date',
            'weight_class_id',
            'length_class_id',
            'product_store',
            'access_token',
            'expires_in',
            'refresh_token',
            'refresh_expires_in',
            'country'

        );

        foreach ($lazada_importer_config as $value) {
            if (isset($this->request->post['lazada_importer_'.$value])) {
                $data['lazada_importer_'.$value] = $this->request->post['lazada_importer_'.$value];
            } else {
                if($value=='app_redirect_uri'){
                    $data['lazada_importer_'.$value] = $this->url->link('module/lazada_importer', 'token=', 'SSL');

                        //'https://192.168.0.108/lazada/importer/admin/index.php?route=module/lazada_importer&token=f7aeccd43f95ff24b305987beca3d6be';
                        //$this->url->link('module/lazada_importer', 'token=' . $this->session->data['token'], 'SSL');
                    //$data['lazada_importer_'.$value] = HTTP_CATALOG .'index.php?route=module/lazada_importer/getcode';
                }
                else if($value=='product_store')
                    $data['lazada_importer_'.$value] = array(0);
                else if(!empty($this->config->get('lazada_importer_'.$value)))
                    $data['lazada_importer_'.$value] = $this->config->get('lazada_importer_'.$value);
                else
                    $data['lazada_importer_'.$value] = '';

            }
        }

        // 0_106177_bmiot8nC5RYBDVs7yUTsAGE31007

        if(isset($this->request->get['code'])){
            $this->model_setting_setting->editSettingValue('lazada_importer', 'lazada_importer_app_code', $this->request->get['code']);
            $getAppData = $this->model_setting_setting->getSetting('lazada_importer');
            $this->load->library('lazadaimporter');
            $cedlazada = LazadaImporter::getInstance($this->registry);
            $result = $cedlazada->getAccessTokenFromLazada($getAppData);
            if(isset($result['access_token']) && !empty($result['access_token'])){
                $data['lazada_importer_access_token'] = $result['access_token'];
                $data['lazada_importer_expires_in'] = $result['expires_in'];
                $data['lazada_importer_refresh_token'] = $result['refresh_token'];
                $data['lazada_importer_refresh_expires_in'] = $result['refresh_expires_in'];
                $data['lazada_importer_country'] = $result['country'];
            }

        }

        $opc_error = array(
            'warning',
            'app_key',
            'app_name',
            'app_redirect_uri',
            'app_code',
            'app_secret',
            'tax_class_id',
            'date_available',
            'weight_class_id',
            'length_class_id',
            'product_store',
            'available_date'
        );

        foreach ($opc_error as $key => $value) {
            if (isset($this->error[$value])) {
                $data['error_'.$value] = $this->error[$value];
            } else {
                $data['error_'.$value] = '';
            }
        }

        $this->load->model('localisation/tax_class');

        $data['tax_classes'] = $this->model_localisation_tax_class->getTaxClasses();

        $this->load->model('localisation/weight_class');

        $data['weight_classes'] = $this->model_localisation_weight_class->getWeightClasses();

        $this->load->model('localisation/length_class');

        $data['length_classes'] = $this->model_localisation_length_class->getLengthClasses();

        $this->load->model('setting/store');

        // Categories
        $this->load->model('catalog/category');

        if (isset($this->request->post['product_category'])) {
            $categories = $this->request->post['product_category'];
        } elseif (isset($this->request->get['product_id'])) {
            $categories = $this->model_catalog_product->getProductCategories($this->request->get['product_id']);
        } elseif(!empty($this->config->get('lazada_importer_product_category'))){
            $categories = $this->config->get('lazada_importer_product_category');
        }  else {
            $categories = array();
        }

        $data['product_categories'] = array();

        foreach ($categories as $category_id) {
            $category_info = $this->model_catalog_category->getCategory($category_id);

            if ($category_info) {
                $data['product_categories'][] = array(
                    'category_id' => $category_info['category_id'],
                    'name' => ($category_info['path']) ? $category_info['path'] . ' &gt; ' . $category_info['name'] : $category_info['name']
                );
            }
        }

        $product_fields = array();
        try{
            $colomns = $this->db->query("SHOW COLUMNS FROM `".DB_PREFIX."product`;");
            if($colomns->num_rows) {
                $product_fields = $colomns->rows;
            }
            $this->array_sort_by_column($product_fields, 'Field');
            $product_fields[] =  array(
                'Field' => 'special_date_start',
                'Type' => 'date',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '0000-00-00',
                'Extra' =>'',
                );
            $product_fields[] =  array(
                'Field' => 'special_end_start',
                'Type' => 'date',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '0000-00-00',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'special_price',
                'Type' => 'float',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '0',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'tag',
                'Type' => 'text',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'meta_title',
                'Type' => 'text',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'meta_description',
                'Type' => 'text',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'meta_keyword',
                'Type' => 'text',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '',
                'Extra' =>'',
            );
        }catch(Exception $e){
            echo $e->getMessage();die;
        }

        $data['stores'] = $this->model_setting_store->getStores();

        $data['product_fields'] = $product_fields;
        $lazada_product_fields = array(
            'quantity',
            'product_weight',
            'SellerSku',
            'ShopSku',
            'package_width',
            'special_to_time',
            'special_from_time',
            'package_height',
            'special_price',
            'price',
            'package_length',
            'package_weight',
            'Available',
            'SkuId',
            'special_to_date',
            'short_description',
            'name',
            'description',
            'warranty_type',
            'brand'
        );
        $data['lazada_product_fields'] = $lazada_product_fields;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('module/lazada_importer.tpl', $data));
    }
    public function array_sort_by_column(&$arr, $col, $dir = SORT_ASC) {
        $sort_col = array();
        foreach ($arr as $key=> $row) {
            $sort_col[$key] = $row[$col];
        }

        array_multisort($sort_col, $dir, $arr);
    }

    protected function validate()
    {
        if (!$this->user->hasPermission('modify', 'module/lazada_importer')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }
    public function generatetoken(){
        $this->load->model('setting/setting');
        $this->load->language('module/lazada_importer');
        $this->model_setting_setting->editSetting('lazada_importer', $this->request->post);
        if(isset($this->request->post['lazada_importer_app_redirect_uri']) && isset($this->request->post['lazada_importer_app_key']))
        $url = 'https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri='.urlencode($this->request->post['lazada_importer_app_redirect_uri']).'&client_id='.$this->request->post['lazada_importer_app_key'];
        $json = array('success' => true, 'message' => $this->language->get('text_success'),'reload' => $url );
        $this->response->setOutput(json_encode($json));
    }
    public function install() {
        $this->load->language('module/lazada_importer');
        $this->load->model('setting/setting');
        $this->load->model('extension/extension');
        $this->load->library('lazadaimporter');
        $lazadaImporter = LazadaImporter::getInstance($this->registry);

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'module/lazada_importer/product');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'module/lazada_importer/product');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'module/lazada_importer/setting');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'module/lazada_importer/setting');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'module/lazada_importer/category');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'module/lazada_importer/category');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'module/lazada_importer');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'module/lazada_importer');

        $isInstalled = $lazadaImporter->isInstalled();
        if(!$isInstalled) {
            $lazadaImporter->install();
        }
    }

    public function uninstall() {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->request->get['extension']);
    }
}

?>
