<?php

class ControllerLazadaImporterCategory extends Controller
{
    private $error = array();

    public function index()
    {
        $this->language->load('module/lazada_importer/category');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('lazada_importer/category');

        $this->getList();
    }

    protected function getList()
    {
        $this->language->load('module/lazada_importer/category');

        if (isset($this->request->get['filter_category_name'])) {
            $filter_category_name = $this->request->get['filter_category_name'];
        } else {
            $filter_category_name = null;
        }

        if (isset($this->request->get['filter_category_id'])) {
            $filter_category_id = $this->request->get['filter_category_id'];
        } else {
            $filter_category_id = null;
        }

        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'category_name';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'ASC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $url = '';

        if (isset($this->request->get['filter_category_name'])) {
            $url .= '&filter_category_name=' . urlencode(html_entity_decode($this->request->get['filter_category_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_category_id'])) {
            $url .= '&filter_category_id=' . urlencode(html_entity_decode($this->request->get['filter_category_id'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('lazada_importer/category', 'token=' . $this->session->data['token'] . $url, 'SSL')
        );

        $data['fetch'] = $this->url->link('lazada_importer/category/fetchCategory', 'token=' . $this->session->data['token'] . $url, 'SSL');
        $data['create'] = $this->url->link('lazada_importer/category/create', 'token=' . $this->session->data['token'] . $url, 'SSL');
        $data['delete'] = $this->url->link('lazada_importer/category/delete', 'token=' . $this->session->data['token'] . $url, 'SSL');

        $data['categorys'] = array();

        $filter_data = array(
            'filter_category_name' => $filter_category_name,
            'filter_category_id' => $filter_category_id,
            'sort' => $sort,
            'order' => $order,
            'start' => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit' => $this->config->get('config_limit_admin')
        );

        $this->load->model('lazada_importer/category');
        $category_total = $this->model_lazada_importer_category->getTotalCategories($filter_data);

        $results = $this->model_lazada_importer_category->getCategories($filter_data);

        foreach ($results as $result) {

            $data['categorys'][] = array(
                'id' => $result['id'],
                'category_id' => $result['category_id'],
                'category_name' => $result['category_name'],
                //'selected' => isset($this->request->post['selected']) && in_array($result['category_id'], $this->request->post['selected']),
            );
        }

        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_list'] = $this->language->get('text_list');

        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_no_results'] = $this->language->get('text_no_results');
        $data['text_image_manager'] = $this->language->get('text_image_manager');

        $data['column_category_id'] = $this->language->get('column_category_id');
        $data['column_category_name'] = $this->language->get('column_category_name');
        $data['column_parent_id'] = $this->language->get('column_parent_id');

        $data['entry_category_id'] = $this->language->get('entry_category_id');
        $data['entry_category_name'] = $this->language->get('entry_category_name');
        $data['entry_parent_id'] = $this->language->get('entry_parent_id');

        $data['column_action'] = $this->language->get('column_action');

        $data['button_add'] = $this->language->get('button_add');
        $data['button_delete'] = $this->language->get('button_delete');
        $data['button_filter'] = $this->language->get('button_filter');

        $data['token'] = $this->session->data['token'];

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        if (isset($this->request->post['selected'])) {
            $data['selected'] = (array)$this->request->post['selected'];
        } else {
            $data['selected'] = array();
        }

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_category_id'])) {
            $url .= '&filter_category_id=' . urlencode(html_entity_decode($this->request->get['filter_category_id'], ENT_QUOTES, 'UTF-8'));
        }

        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['sort_category_name'] = $this->url->link('lazada_importer/category', 'token=' . $this->session->data['token'] . '&sort=category_name' . $url, 'SSL');
        $data['sort_category_id'] = $this->url->link('lazada_importer/category', 'token=' . $this->session->data['token'] . '&sort=category_id' . $url, 'SSL');

        $url = '';

        if (isset($this->request->get['filter_category_name'])) {
            $url .= '&filter_category_name=' . urlencode(html_entity_decode($this->request->get['filter_category_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_category_id'])) {
            $url .= '&filter_category_id=' . urlencode(html_entity_decode($this->request->get['filter_category_id'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        $pagination = new Pagination();
        $pagination->total = $category_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->text = $this->language->get('text_pagination');
        $pagination->url = $this->url->link('lazada_importer/category', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($category_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($category_total - $this->config->get('config_limit_admin'))) ? $category_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $category_total, ceil($category_total / $this->config->get('config_limit_admin')));

        $data['filter_category_name'] = $filter_category_name;
        $data['filter_category_id'] = $filter_category_id;

        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header']  = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('module/lazada_importer/category_import.tpl', $data));
    }

    public function fetchCategory()
    {
        $this->load->model('setting/setting');
        $getData = $this->model_setting_setting->getSetting('lazada');

        $baseDirectory = DIR_SYSTEM . 'var/lazada_importer/categories/';
        if(!is_dir($baseDirectory)){
            mkdir($baseDirectory, 0777, true);
        }
        $path = $baseDirectory . 'categoriesTree_'. $getData['lazada_importer_country'] .'.json';
        chmod($path, 0777);

        if(file_exists($path) && !empty(file_get_contents($path))){
            $categoryTree = file_get_contents($path);
        } else {
            $this->load->library('lazadaimporter');
            $cedlazada = LazadaImporter::getInstance($this->registry);
            $config = $cedlazada->getConfigData($getData, 'category');

            $product = new \Lazada\Sdk\Api\Product($config);
            $response = $product->getCategories(true);

            $this->load->model('lazada_importer/category');
            $result = $this->model_lazada_importer_category->generateCategoryTree($response, $getData['lazada_importer_country']);

            if (!file_exists($path)) {
                if(!empty($result))
                    file_put_contents($path, json_encode($result));
                if (file_exists($path))
                    $categoryTree = file_get_contents($path);
            } else {
                if(!empty($result))
                    file_put_contents($path, json_encode($result));
                $categoryTree = file_get_contents($path);
            }
        }

        if(!empty($categoryTree)){
            $this->session->data['success'] = 'Categories fetched Successfully! <br/> Kindly refresh your page.';
        } else {
            $this->session->data['error_warning'] = 'Can\'t fetch Categories!';
        }

        $this->getList();
    }

    public function create() {
        $this->language->load('module/lazada_importer/category');

        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('lazada_importer/category');
        $this->load->model('catalog/category');

        if (isset($this->request->post['selected']) && !empty($this->request->post['selected'])) {
            foreach ($this->request->post['selected'] as $cat_pk) {
                $catData = $this->model_lazada_importer_category->getCategoryDataByID($cat_pk);
                $storeCatID = $this->model_catalog_category->addCategory($catData);
                $this->model_lazada_importer_category->UpdateStoreCatID($storeCatID, $cat_pk);
            }

            $this->session->data['success'] = 'Category Created on Store Successfully!';

            $url = '';

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $this->response->redirect($this->url->link('lazada_importer/category', 'token=' . $this->session->data['token'] . $url, 'SSL'));
        }

        $this->getList();
    }

    public function delete() {
        $this->language->load('module/lazada_importer/category');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('lazada_importer/category');

        if (isset($this->request->post['selected']) && $this->validateDelete()) {
            foreach ($this->request->post['selected'] as $cat_pk) {
                $this->model_lazada_importer_category->deleteCategory($cat_pk);
            }

            $this->session->data['success'] = $this->language->get('text_success');

            $url = '';

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $this->response->redirect($this->url->link('lazada_importer/category', 'token=' . $this->session->data['token'] . $url, 'SSL'));
        }

        $this->getList();
    }
    protected function validateDelete() {
        if (!$this->user->hasPermission('modify', 'lazada_importer/category')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }
}
?>