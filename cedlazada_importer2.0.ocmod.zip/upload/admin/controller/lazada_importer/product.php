<?php
require_once DIR_SYSTEM . "library/lazada-sdk/Autoloader.php";

class ControllerLazadaImporterProduct extends Controller
{
    private $error = array();

    public function index()
    {
        $data = $this->load->language('module/lazada_importer/product');
        $this->load->model('lazada_importer/setting');

        $this->document->setTitle($this->language->get('heading_title'));

        $data['heading_title'] = $this->language->get('heading_title');
        //entry
        $data['entry_site_key'] = $this->language->get('entry_site_key');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_ecommerce_tracking'] = $this->language->get('entry_ecommerce_tracking');

        //text
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_help_site_key'] = $this->language->get('text_help_site_key');
        $data['text_help_ecommerce_tracking'] = $this->language->get('text_help_ecommerce_tracking');
        $data['text_where_find_key'] = $this->language->get('text_where_find_key');

        //buttons texts
        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');
        $data['button_add_module'] = $this->language->get('button_add_module');
        $data['button_remove'] = $this->language->get('button_remove');

        //breadcrumbs
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => false
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_module'),
            'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => ' :: '
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('module/lazada_importer_product', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => ' :: '
        );

        $data['action'] = $this->url->link('module/lazada_importer', 'token=' . $this->session->data['token'], 'SSL');

        $data['fetchProduct'] = $this->url->link('lazada_importer/product/fetchProduct', 'token=' . $this->session->data['token'], 'SSL');
        $data['token'] = $this->session->data['token'];
        $setting_data = array();
        if(isset($this->request->get['id']) && $this->request->get['id']){
            $setting_data =$this->model_lazada_importer_setting->getSetting($this->request->get['id']);
            if(isset( $setting_data['search_data']) &&  $setting_data['search_data']){
                $setting_data = @json_decode( $setting_data['search_data'],true);
            }

            if(empty($setting_data))
                $setting_data =array();
        }
        $opc_error = array(
            'warning',
            'filter'
        );

        foreach ($opc_error as $key => $value) {
            if (isset($this->error[$value])) {
                $data['error_' . $value] = $this->error[$value];
            } else {
                $data['error_' . $value] = '';
            }
        }
        $lazada_importer_config = array(
            'filter',
            'update_before',
            'search',
            'create_before',
            'offset',
            'create_after',
            'update_after',
            'limit',
            'options',
            'sku_seller_list'
        );

        foreach ($lazada_importer_config as $key => $value) {
            if (isset($this->request->post[$value])) {
                $data[$value] = $this->request->post[$value];
            } elseif (isset($setting_data[$value])) {
                $data[$value] = $setting_data[$value];
            } else {
                $data[$value] = '';
            }
        }

        $data['filter'] = array(
            'all' => 'All',
            'live' => 'Live',
            'inactive' => 'Inactive',
            'deleted' => 'Deleted',
            'image-missing' => 'Image Missing',
            'pending' => 'Pending',
            'rejected' => 'Rejected',
            'sold-out' => 'Sold Out'
        );

        $data['settings'] = $this->model_lazada_importer_setting->getSettings();
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('module/lazada_importer/product_import.tpl', $data));
    }

    public function getFilterData(){
        $json = array();
        $post_data = $this->request->post;

        $this->load->model('lazada_importer/setting');
        if($post_data['import_setting'] != '0'){
            $result = $this->model_lazada_importer_setting->getSetting($post_data['import_setting']);

            if(isset($result['search_data']) && $result['search_data'])
            {
                $json['success'] = true;
                $json['data'] = json_decode($result['search_data'], true);
            } else {
                $json['success'] = false;
                $json['data'] = '';
            }
        }

        $this->response->setOutput(json_encode($json));
    }

    public function fetchProduct()
    {
        $json = array();
        $post_data = $this->request->post;
        $filter_data = $post_data['filter_setting'];

        unset($post_data['filter_setting']);

        $this->load->model('setting/setting');
        $result = $this->model_setting_setting->getSetting('lazada');


        $this->load->library('lazadaimporter');
        $cedlazada = LazadaImporter::getInstance($this->registry);
        $config = $cedlazada->getConfigData($result, 'product');

        if(empty($post_data))
            $post_data = array();

        $product = new \Lazada\Sdk\Api\Product($config);
        $response = (array)$product->getProducts($post_data);
        if(isset($response['code']) && $response['code'] == '0' && isset($response['data']) && !empty($response['data'])){
            if($filter_data != '0') {
                $this->load->model('lazada_importer/setting');
                $import_setting_data = $this->model_lazada_importer_setting->getSetting($filter_data);
            } else {
                $import_setting_data = array();
            }
            
            if(isset($import_setting_data['search_data']) && !empty($import_setting_data['search_data']))
                $import_setting_data = json_decode($import_setting_data['search_data'], true);
            $result = $cedlazada->prepareProductData($filter_data, $response['data']['products'], $import_setting_data);
//            echo '<pre>'; print_r($result); die;
            if(isset($result['success']) && $result['success']==true)
            {
                $json['success'] = true;
                 if(!empty($result['message']))
                    $json['message'] = $result['message'];
                 else
                   $json['message'] = 'Products Fetched Successfully!';
            } else {
                $json['success'] = false;
                 if(!empty($result['message']))
                    $json['message'] = $result['message'];
                 else
                   $json['message'] = 'Product(s) already imported!';
            }
        } else {
            $json['success'] = false;
            $json['message'] = 'No new Product(s) to import!';
        }

//        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }


}

?>
