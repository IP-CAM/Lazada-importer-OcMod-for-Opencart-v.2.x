<?php class ControllerLazadaImporterSetting extends Controller
{
    private $error = array();

    public function index() {
        $this->load->language('module/lazada_importer/setting');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('lazada_importer/setting');

        $this->getList();
    }

    public function add() {
        $this->load->language('module/lazada_importer/setting');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('lazada_importer/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
            $this->model_lazada_importer_setting->addSetting($this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $url = '';

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $this->response->redirect($this->url->link('lazada_importer/setting', 'token=' . $this->session->data['token'] . $url, 'SSL'));
        }

        $this->getForm();
    }

    public function edit() {
        $this->load->language('module/lazada_importer/setting');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('lazada_importer/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
//echo '<pre>'; print_r($this->request->post); die;
            $this->model_lazada_importer_setting->updateSetting($this->request->get['id'], $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $url = '';

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $this->response->redirect($this->url->link('lazada_importer/setting', 'token=' . $this->session->data['token'] . $url, 'SSL'));
        }

        $this->getForm();
    }

    public function delete() {
        $this->load->language('module/lazada_importer/setting');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('lazada_importer/setting');
//echo '<pre>'; print_r($this->request->post); die;
        if (isset($this->request->post['selected']) && $this->validateDelete()) {
            foreach ($this->request->post['selected'] as $id) {
                $this->model_lazada_importer_setting->deleteSetting($id);
            }

            $this->session->data['success'] = $this->language->get('text_success');

            $url = '';

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $this->response->redirect($this->url->link('lazada_importer/setting', 'token=' . $this->session->data['token'] . $url, 'SSL'));
        }

        $this->getList();
    }

    protected function getList() {
        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'agd.name';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'ASC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $url = '';

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('lazada_importer/setting', 'token=' . $this->session->data['token'] . $url, 'SSL')
        );

        $data['add'] = $this->url->link('lazada_importer/setting/add', 'token=' . $this->session->data['token'] . $url, 'SSL');
        $data['delete'] = $this->url->link('lazada_importer/setting/delete', 'token=' . $this->session->data['token'] . $url, 'SSL');

        $data['searchs'] = array();

        $filter_data = array(
            'sort'  => $sort,
            'order' => $order,
            'start' => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit' => $this->config->get('config_limit_admin')
        );

        $attribute_group_total = $this->model_lazada_importer_setting->getTotalSettings();

        $results = $this->model_lazada_importer_setting->getSettings($filter_data);

        foreach ($results as $result) {
            $data['searchs'][] = array(
                'id'         => $result['id'],
                'filter'     => $result['filter'],
                'search'     => $result['search'],
                'edit'       => $this->url->link('lazada_importer/setting/edit', 'token=' . $this->session->data['token'] . '&id=' . $result['id'] . $url, 'SSL')
            );
        }

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_list'] = $this->language->get('text_list');
        $data['text_no_results'] = $this->language->get('text_no_results');
        $data['text_confirm'] = $this->language->get('text_confirm');

        $data['column_id']     = $this->language->get('column_id');
        $data['column_filter'] = $this->language->get('column_filter');
        $data['column_search'] = $this->language->get('column_search');
        $data['column_action'] = $this->language->get('column_action');

        $data['button_add'] = $this->language->get('button_add');
        $data['button_edit'] = $this->language->get('button_edit');
        $data['button_delete'] = $this->language->get('button_delete');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        if (isset($this->request->post['selected'])) {
            $data['selected'] = (array)$this->request->post['selected'];
        } else {
            $data['selected'] = array();
        }

        $url = '';

        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['sort_name'] = $this->url->link('lazada_importer/setting', 'token=' . $this->session->data['token'] . '&sort=agd.name' . $url, 'SSL');
        $data['sort_sort_order'] = $this->url->link('lazada_importer/setting', 'token=' . $this->session->data['token'] . '&sort=ag.sort_order' . $url, 'SSL');

        $url = '';

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        $pagination = new Pagination();
        $pagination->total = $attribute_group_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->url = $this->url->link('lazada_importer/setting', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($attribute_group_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($attribute_group_total - $this->config->get('config_limit_admin'))) ? $attribute_group_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $attribute_group_total, ceil($attribute_group_total / $this->config->get('config_limit_admin')));

        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('module/lazada_importer/setting_import_list.tpl', $data));
    }

    protected function validateForm() {
        if (!$this->user->hasPermission('modify', 'lazada_importer/setting')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

            if ((utf8_strlen($this->request->post['filter']) < 3) || (utf8_strlen($this->request->post['filter']) > 64)) {
                $this->error['filter'] = $this->language->get('error_filter');
            }


        return !$this->error;
    }

    protected function validateDelete() {
        if (!$this->user->hasPermission('modify', 'lazada_importer/setting')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }

    public function getForm()
    {
        $data = array();
        $data = $this->load->language('module/lazada_importer/setting');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('lazada_importer/setting');

        $data['heading_title'] = $this->language->get('heading_title');
        $data['lazada_importer_key'] = html_entity_decode($this->config->get('lazada_importer_key'));

        //entry
        $data['entry_site_key'] = $this->language->get('entry_site_key');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_ecommerce_tracking'] = $this->language->get('entry_ecommerce_tracking');

        //text
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_help_site_key'] = $this->language->get('text_help_site_key');
        $data['text_help_ecommerce_tracking'] = $this->language->get('text_help_ecommerce_tracking');
        $data['text_where_find_key'] = $this->language->get('text_where_find_key');

        //buttons texts
        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');
        $data['button_add_module'] = $this->language->get('button_add_module');
        $data['button_remove'] = $this->language->get('button_remove');

        //breadcrumbs
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => false
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_module'),
            'href' => $this->url->link('extension/module/lazada_importer', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => ' :: '
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_module'),
            'href' => $this->url->link('extension/module/lazada_importer/setting', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => ' :: '
        );

        if(isset($this->request->get['id']) && $this->request->get['id'])
        $data['action'] = $this->url->link('lazada_importer/setting/edit', 'token=' . $this->session->data['token'].'&id='.$this->request->get['id'], 'SSL');
        else
        $data['action'] = $this->url->link('lazada_importer/setting/add', 'token=' . $this->session->data['token'], 'SSL');

        $data['cancel'] = $this->url->link('lazada_importer/setting', 'token=' . $this->session->data['token'], 'SSL');
        $data['token'] = $this->session->data['token'];
        $setting_data = array();
        if(isset($this->request->get['id']) && $this->request->get['id']){
            $setting_data =$this->model_lazada_importer_setting->getSetting($this->request->get['id']);
            if(isset( $setting_data['search_data']) &&  $setting_data['search_data']){
                $setting_data = @json_decode( $setting_data['search_data'],true);
            }
//            echo '<pre>'; print_r($setting_data); die;
           if(isset($setting_data['field_mapping']) && !empty($setting_data['field_mapping'])){
               foreach($setting_data['field_mapping'] as $index => $value){
                   $data['field_mapping_'.$index] = $value;
               }
           }

            if(empty($setting_data))
                $setting_data =array();
        }
        $opc_error = array(
            'warning',
            'filter',
            'available_date'
        );

        foreach ($opc_error as $key => $value) {
            if (isset($this->error[$value])) {
                $data['error_' . $value] = $this->error[$value];
            } else {
                $data['error_' . $value] = '';
            }
        }
        $lazada_importer_config = array(
            'filter',
            'update_before',
            'search',
            'create_before',
            'offset',
            'create_after',
            'update_after',
            'limit',
            'options',
            'sku_seller_list',
            'tax_class_id',
            'date_available',
            'weight_class_id',
            'length_class_id',
            'product_store',
            'available_date'
        );

        foreach ($lazada_importer_config as $key => $value) {
            if (isset($this->request->post[$value])) {
                $data[$value] = $this->request->post[$value];
            } elseif ($value == 'product_store'){
                $data['product_store'] = array(0);
            } elseif (isset($setting_data[$value])) {
                $data[$value] = $setting_data[$value];
            } else {
                $data[$value] = '';
            }
        }
//        echo '<pre>'; print_r($data); die;
        $this->load->model('localisation/tax_class');

        $data['tax_classes'] = $this->model_localisation_tax_class->getTaxClasses();

        $this->load->model('localisation/weight_class');

        $data['weight_classes'] = $this->model_localisation_weight_class->getWeightClasses();

        $this->load->model('localisation/length_class');

        $data['length_classes'] = $this->model_localisation_length_class->getLengthClasses();

        $this->load->model('setting/store');

        // Categories
        $this->load->model('catalog/category');

        if (isset($this->request->post['product_category'])) {
            $categories = $this->request->post['product_category'];
        } elseif (isset($this->request->get['product_id'])) {
            $categories = $this->model_catalog_product->getProductCategories($this->request->get['product_id']);
        } elseif(isset($setting_data['product_category']) && !empty($setting_data['product_category'])){
            $categories = $setting_data['product_category'];
        } else {
            $categories = array();
        }

        $data['product_categories'] = array();

        foreach ($categories as $category_id) {
            $category_info = $this->model_catalog_category->getCategory($category_id);

            if ($category_info) {
                $data['product_categories'][] = array(
                    'category_id' => $category_info['category_id'],
                    'name' => ($category_info['path']) ? $category_info['path'] . ' &gt; ' . $category_info['name'] : $category_info['name']
                );
            }
        }

        $product_fields = array();
        try{
            $colomns = $this->db->query("SHOW COLUMNS FROM `".DB_PREFIX."product`;");
            if($colomns->num_rows) {
                $product_fields = $colomns->rows;
            }
            $this->array_sort_by_column($product_fields, 'Field');
            $product_fields[] =  array(
                'Field' => 'special_date_start',
                'Type' => 'date',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '0000-00-00',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'special_end_start',
                'Type' => 'date',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '0000-00-00',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'special_price',
                'Type' => 'float',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '0',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'tag',
                'Type' => 'text',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'meta_title',
                'Type' => 'text',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'meta_description',
                'Type' => 'text',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'meta_keyword',
                'Type' => 'text',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '',
                'Extra' =>'',
            );
        }catch(Exception $e){
            echo $e->getMessage();die;
        }

        $data['stores'] = $this->model_setting_store->getStores();

        $data['product_fields'] = $product_fields;
        $lazada_product_fields = array(
            'quantity',
            'product_weight',
            'SellerSku',
            'ShopSku',
            'package_width',
            'special_to_time',
            'special_from_time',
            'package_height',
            'special_price',
            'price',
            'package_length',
            'package_weight',
            'Available',
            'SkuId',
            'special_to_date',
            'short_description',
            'name',
            'description',
            'warranty_type',
            'brand'
        );
        $data['lazada_product_fields'] = $lazada_product_fields;

        $data['filters'] = array(
            'all' => 'All',
            'live' => 'Live',
            'inactive' => 'Inactive',
            'deleted' => 'Deleted',
            'image-missing' => 'Image Missing',
            'pending' => 'Pending',
            'rejected' => 'Rejected',
            'sold_out' => 'Sold Out'
        );
        
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('module/lazada_importer/setting_import.tpl', $data));
    }
    public function array_sort_by_column(&$arr, $col, $dir = SORT_ASC) {
        $sort_col = array();
        foreach ($arr as $key=> $row) {
            $sort_col[$key] = $row[$col];
        }

        array_multisort($sort_col, $dir, $arr);
    }

    protected function validate()
    {
        if (!$this->user->hasPermission('modify', 'module/lazada_importer')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }
}

?>
