<?php
class ModelLazadaImporterSetting extends Model {
	public function addSetting($data) {
		$this->event->trigger('pre.admin.lazada_setting.add', $data);
		$this->db->query("INSERT INTO " . DB_PREFIX . "lazada_importer_settings SET filter = '" . $this->db->escape($data['filter']) . "', search = '" . $this->db->escape($data['search']) . "', search_data = '" . $this->db->escape(json_encode($data)) . "'");


		$id = $this->db->getLastId();

		$this->event->trigger('post.admin.lazada_setting.add', $id);

		return $id;
	}

	public function updateSetting($id, $data) {
		$this->event->trigger('pre.admin.lazada_setting.edit', $data);

		$this->db->query("UPDATE " . DB_PREFIX . "lazada_importer_settings SET filter = '" . $this->db->escape($data['filter']) . "', search = '" . $this->db->escape($data['search']) . "', search_data = '" . $this->db->escape(json_encode($data)) . "' WHERE id = '" . (int)$id . "'");

		$this->event->trigger('post.admin.lazada_setting.edit', $id);
	}

	public function deleteSetting($id) {
		$this->event->trigger('pre.admin.ced_lazada_setting.delete', $id);

		$this->db->query("DELETE FROM " . DB_PREFIX . "lazada_importer_settings WHERE id = '" . (int)$id . "'");
		$this->event->trigger('post.admin.ced_lazada_setting.delete', $id);
	}

	public function getSetting($id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "lazada_importer_settings WHERE id = '" . (int)$id . "'");

		return $query->row;
	}

	public function getSettings($data = array()) {
		$sql = "SELECT * FROM " . DB_PREFIX . "lazada_importer_settings ";

		$sort_data = array(
			'filter',
			'id'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}



	public function getTotalSettings() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "lazada_importer_settings");

		return $query->row['total'];
	}
}