<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   lazada_importer
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */
class ModelLazadaImporterCategory extends Model {

    public function getCategories($data = array()) {

        $sql = "SELECT * FROM " . DB_PREFIX . "lazada_importer_category WHERE category_id >0 AND leaf > 0";

        if (!empty($data['filter_category_name'])) {
            $sql .= " AND category_name LIKE '%" .  iconv("UTF-8", "ISO-8859-1", $this->db->escape($data['filter_category_name'])) . "%'";
        }

        if (!empty($data['filter_category_id'])) {
            $sql .= " AND category_id = '" . $this->db->escape($data['filter_category_id']) . "'";
        }

        $sql .= " GROUP BY category_id";

        $sort_data = array(
            'category_name',
            'category_id'
        );

        if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
            $sql .= " ORDER BY " . $data['sort'];
        } else {
            $sql .= " ORDER BY category_name";
        }

        if (isset($data['start']) || isset($data['limit'])) {
            if ($data['start'] < 0) {
                $data['start'] = 0;
            }

            if ($data['limit'] < 1) {
                $data['limit'] = 20;
            }

            $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
        }
        
        $query = $this->db->query($sql);

        return $query->rows;
    }
    public function deleteCategory($category_id) {
        $this->db->query("DELETE FROM `".DB_PREFIX."lazada_importer_category` WHERE `id`='". (int)$category_id ."'");
    }

    public function getTotalCategories($data = array())
    {
        $sql = "SELECT count(category_id) AS total FROM " . DB_PREFIX . "lazada_importer_category WHERE category_id > '0' ";

        if (!empty($data['filter_category_name'])) {
            $sql .= " AND category_name LIKE '%" .  iconv("UTF-8", "ISO-8859-1", $this->db->escape($data['filter_category_name'])) . "%'";
            //$sql .= " AND category_name LIKE '%" . $this->db->escape($data['filter_category_name']) . "%'";
        }

        if (!empty($data['filter_category_id'])) {
            $sql .= " AND category_id = '" . $this->db->escape($data['filter_category_id']) . "'";
        }

        $query = $this->db->query($sql);

        return $query->row['total'];
    }

    public function generateCategoryTree($categories, $regionId){
        $this->db->query("DELETE FROM `".DB_PREFIX."lazada_importer_category` WHERE `region`='". $this->db->escape($regionId) ."'");
        $data = array();
        foreach ($categories as $key => $category) {
            $this->db->query("INSERT INTO `".DB_PREFIX."lazada_importer_category` (`category_id`, `category_name`, `leaf`, `is_active`, `label`, `region`) VALUES('". (int)$category['category_id'] ."', '". $this->db->escape($category['name']) ."', '". (int)$category['leaf'] ."', false, '". $this->db->escape($category['name']) ."','". $this->db->escape($regionId) ."') ");
            $item = array();
            $item['value'] = $category['category_id'];
            $item['leaf'] = $category['leaf'];
            $item['is_active'] = false;
            $item['label'] = $category['name'];
            $item['region'] = $regionId;
            if (isset($category['children']) and !empty($category['children'])) {
                $item['optgroup'] = $this->generateCategoriesTree($category['children'], $regionId, $category['category_id']);
            }
            $data[trim($category['name'])] = $item;
        }
        return $data;
    }

    private function generateCategoriesTree($categories = array(), $regionId = '', $parentCatID)
    {
        $data = array();

        foreach ($categories as $key => $category) {

            $query = $this->db->query("SELECT category_name FROM `". DB_PREFIX ."lazada_importer_category` WHERE `category_id` = '". $parentCatID ."' AND `leaf` = '0' ");
            if($query->num_rows){
                $this->db->query("INSERT INTO `".DB_PREFIX."lazada_importer_category` (`category_id`, `category_name`, `leaf`, `is_active`, `label`, `region`) VALUES('". (int)$category['category_id'] ."', '". strip_tags(html_entity_decode($this->db->escape($query->row['category_name'].' > '.$category['name']), ENT_QUOTES, 'UTF-8')) ."', '". (int)$category['leaf'] ."', false, '". $this->db->escape($category['name']) ."','". $this->db->escape($regionId) ."') ");
            } else {
                $this->db->query("INSERT INTO `".DB_PREFIX."lazada_importer_category` (`category_id`, `category_name`, `leaf`, `is_active`, `label`, `region`) VALUES('". (int)$category['category_id'] ."', '". strip_tags(html_entity_decode($this->db->escape($category['name']), ENT_QUOTES, 'UTF-8')) ."', '". (int)$category['leaf'] ."', false, '". strip_tags(html_entity_decode($this->db->escape($category['name']), ENT_QUOTES, 'UTF-8')) ."','". $this->db->escape($regionId) ."') ");
            }
            $item = array();
            $item['value'] = $category['category_id'];
            $item['leaf'] = $category['leaf'];
            $item['is_active'] = false;
            if ($item['leaf']) {
                $item['is_active'] = true;
            }
            $item['label'] = $category['name'];
            $item['region'] = $regionId;
            if (isset($category['children']) and !empty($category['children'])) {
                $item['optgroup'] = $this->generateCategoriesTree($category['children'], $regionId, $category['category_id']);
            }

            $data[trim($category['name'])] = $item;
        }
        return $data;
    }

    public function getCategoryDataByID($catPkID){
        $sql = $this->db->query("SELECT * FROM `". DB_PREFIX ."lazada_importer_category` WHERE `id` = '". $catPkID ."' ");
        if($sql->num_rows){
            $catData = $sql->row;

            $catData['column'] = '0';
            $catData['parent_id'] = '0';
            $catData['sort_order'] = '0';
            $catData['status'] = '1';
            $lang = $this->config->get('config_language_id');
            $catData['category_description'][$lang] = array(
                'name' => $catData['category_name'],
                'description' => $catData['category_name'],
                'meta_title' => '',
                'meta_description' => '',
                'meta_keyword' => ''
            );
            return $catData;
        } else {
            return array();
        }
    }

    public function UpdateStoreCatID($storeCatID, $catPkID){
        $this->db->query("UPDATE `". DB_PREFIX ."lazada_importer_category` SET `store_category_id` = '". $storeCatID ."' WHERE `id` = '". $catPkID ."' ");
    }
}