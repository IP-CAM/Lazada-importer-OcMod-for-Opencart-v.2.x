<?php
// Heading
$_['heading_title'] = 'Lazada Importer By Cedcommerce';

//tab
$_['tab_general'] = 'Setting';
$_['tab_default'] = 'Default Values';
$_['tab_mapping'] = 'Field Mapping';

//Text
$_['text_module'] = 'Modules';
$_['text_none'] = 'None';
$_['text_yes'] = 'Modules';
$_['text_edit']= 'Edit Importer Configuration';
$_['text_success'] = 'Success: You have modified module Lazada Importer!';

//Entry
$_['entry_status'] = 'Status';
$_['entry_category'] = 'Default Category';
$_['entry_store'] = 'Store(s) In Created Product';
$_['entry_weight_class'] = 'Weight Class';
$_['entry_tax_class'] = 'Tax Class';
$_['entry_length_class'] = 'Length Class';
$_['entry_available_date'] = 'Available Date';

$_['entry_app_name'] = 'APP Name';
$_['entry_app_key'] = 'APP Key';
$_['entry_app_secret'] = 'APP Secret';
$_['entry_app_redirect_uri'] = 'Redirect URI';
$_['entry_app_code'] = 'APP Code';

$_['button_get_code'] = 'Generate Code';

//Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Lazada Importer!';
$_['error_app_name'] = 'APP Name is Required.';
$_['error_app_key'] = 'APP Key is Required.';
$_['error_app_secret'] = 'APP Secret is Required.';
$_['error_app_redirect_uri'] = 'Redirect URI is Required.';
$_['error_app_code'] = 'APP Code is Required.';