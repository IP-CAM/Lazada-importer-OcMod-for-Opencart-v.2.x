<?php
// Heading
$_['heading_title'] = 'Import Lazada Product(s)';

//Text
$_['text_module'] = 'Modules';
$_['text_edit']= 'Import Lazada Product(s)';
$_['text_success'] = 'Success: You have modified module Lazada Product(s) Importer!';

//Entry
$_['entry_setting_name'] = 'Select Import Setting';
$_['entry_filter'] = 'Filter';
$_['entry_update_before'] = 'Update Before';
$_['entry_search'] = 'Search';
$_['entry_create_before'] = 'Create Before';
$_['entry_offset'] = 'Offset';
$_['entry_create_after'] = 'Create After';
$_['entry_update_after'] = 'Update After';
$_['entry_limit'] = 'Limit';
$_['entry_options'] = 'Option';
$_['entry_sku_seller_list'] = 'SKU Seller List(Comma(,) Seperated)';

//Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Lazada Importer!';