<?php
/**
* Parent:
*            <name>api create product test sample</name>
*            <short_description>This is a nice product</short_description>
*            <brand>Remark</brand>
*            <model>asdf</model>
*/

/** 
 * Child: 
 *               <SellerSku>api-create-test-1</SellerSku>
 *               <color_family>Green</color_family>
 *               <size>40</size>
 *               <quantity>1</quantity>
 *               <price>388.50</price>
*/


$product = [
  'Product' => [
                        '_attribute' => [],
                        '_value' => [
                                0 => [
                                    'PrimaryCategory' => (string)1234, // category id
                                    'SPUId' => '', //lazada product id
                                    'Attributes' => [
                                    ]
                                    'Skus' =>
                                        [
                                            '_attribute' => [],
                                            '_value' => [
                                                0 => [
                                                   'Sku' => [
                                                                '_attribute' => [],
                                                                '_value' => []
                                                            ],
                                                ]
                                            ]
                                        ]
                                ],
                        ]
                    ]
];

