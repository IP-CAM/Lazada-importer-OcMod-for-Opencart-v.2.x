<?php

/**
* Get a File or Create
* @param $path
* @param null $name
* @return string
*/
function getFile($path, $name = null)
{
    if (!file_exists($path)) {
        @mkdir($path, 0777, true);
    }
    
    if ($name != null) {
        $path = $path . DIRECTORY_SEPARATOR . $name;
        if (!file_exists($path)) {
            @file($path);
        }
    }
    
    return $path;
}
?>