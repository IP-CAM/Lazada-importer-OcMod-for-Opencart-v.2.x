<?php
$config = null;
$orderList = new \Lazada\Sdk\Order($config);
// status: pending, canceled, ready_to_ship, delivered, returned, shipped and failed.

$createdAfter = date('Y-m-d\TH:i:sP', strtotime('-3 months'));

/** @var \Lazada\Sdk\Api\Response $orders */
$orders = $orderList->getOrders([
    'status' => 'pending',
    'limit' => '1',
    'created_after' => $createdAfter
]);
$orders = $orders->getBody();
