<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @package     Lazada-Sdk
 * @author      CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (http://cedcommerce.com/)
 * @license     http://cedcommerce.com/license-agreement.txt
 */

namespace Lazada\Sdk\Api;

class Order extends \Lazada\Sdk\Api\Api
{

    /**
     * Get all orders
     * @param array $params
     * @return \Lazada\Sdk\Api\Response
     * @link https://open.lazada.com/doc/api.htm?spm=a2o9m.11193487.0.0.3ac413feY2OZgD#/api?cid=8&path=/orders/get
     */
    public function getOrders(array $params = [])
    {
        $orders = new \Lazada\Sdk\Api\Response([]);
        $orders->setAction(self::ACTION_GET_ORDERS);
        try {
            $client = new \Lazada\Sdk\Api\Client($this->config);
            $request = new \Lazada\Sdk\Api\Request('/orders/get', 'GET');
            foreach ($params as $index => $value) {
                $request->addApiParam($index, $value);
            }
            $orders = $client->execute($request, $this->config->getAccessToken());
            // $orders->load($response);
        } catch (\Exception $e) {
            if ($this->config->getDebugMode()) {
                $this->config->getLogger()->debug($e->getMessage(), ['path' => __METHOD__]);
            }
        }

        return $orders;
    }

    /**
     * Get an Order
     * @param array $params
     * @return \Lazada\Sdk\Api\Response
     * @link https://open.lazada.com/doc/api.htm?spm=a2o9m.11193487.0.0.3ac413feY2OZgD#/api?cid=8&path=/order/get
     */
    public function getOrder($orderId)
    {
        $order = new \Lazada\Sdk\Api\Response([]);
        $order->setAction(self::ACTION_GET_ORDER);
        try {
            $client = new \Lazada\Sdk\Api\Client($this->config);
            $request = new \Lazada\Sdk\Api\Request('/order/get', 'GET');
            $request->addApiParam('order_id', $orderId);
            $order = $client->execute($request, $this->config->getAccessToken());
            // $order->load($response);
        } catch (\Exception $e) {
            if ($this->config->getDebugMode()) {
                $this->config->getLogger()->debug($e->getMessage(), ['path' => __METHOD__]);
            }
        }

        return $order;
    }

    /**
     * Get order items
     * @param string $orderId
     * @return \Lazada\Sdk\Api\Response
     * @link https://open.lazada.com/doc/api.htm?spm=a2o9m.11193487.0.0.3ac413feY2OZgD#/api?cid=8&path=/order/items/get
     */
    public function getOrderItems($orderId)
    {
        $orderItems = new \Lazada\Sdk\Api\Response([]);
        $orderItems->setAction(self::ACTION_GET_ORDER_ITEMS);
        try {
            $client = new \Lazada\Sdk\Api\Client($this->config);
            $request = new \Lazada\Sdk\Api\Request('/order/items/get', 'GET');
            $request->addApiParam('order_id', $orderId);
            $orderItems = $client->execute($request, $this->config->getAccessToken());
            // $orderItems->load($response);
        } catch (\Exception $e) {
            if ($this->config->getDebugMode()) {
                $this->config->getLogger()->debug($e->getMessage(), ['path' => __METHOD__]);
            }
        }

        return $orderItems;
    }

    /**
     * Cancel an order item
     * @param array $params
     * @return array|Api\Response
     * @link https://open.lazada.com/doc/api.htm?spm=a2o9m.11193487.0.0.3ac413feY2OZgD#/api?cid=8&path=/order/cancel
     */
    public function cancelOrderItem(array $params = [])
    {
        $orderItems = new \Lazada\Sdk\Api\Response([]);
        $orderItems->setAction(self::ACTION_POST_CANCEL_ORDER_ITEM);
        try {
            $client = new \Lazada\Sdk\Api\Client($this->config);
            $request = new \Lazada\Sdk\Api\Request('/order/cancel');
            //$request->addApiParam('reason_detail', $params['reason_detail']);
            $request->addApiParam('reason_id', $params['reason_id']);
            $request->addApiParam('order_item_id', $params['order_item_id']);
            $orderItems = $client->execute($request, $this->config->getAccessToken());
            // $orderItems->load($response);
            // if ($this->config->getDebugMode()) {
            //     $path = $this->getFile(
            //         $this->config->getBaseDirectory(),
            //         self::ACTION_POST_CANCEL_ORDER_ITEM . '-' .
            //         $this->config->getRegion(). '-'. $this->getSuffix() . '.json'
            //     );
            //     @file_put_contents($path, json_encode($params));
            //     $orderItems->setFeedFile($path);
            // }
        } catch (\Exception $e) {
            if ($this->config->getDebugMode()) {
                $this->config->getLogger()->debug($e->getMessage(), ['path' => __METHOD__]);
            }
        }
        return $orderItems;
    }

    /**
     * Set items to packed
     * @param array $params
     * @return array|Api\Response
     * @link https://open.lazada.com/doc/api.htm?spm=a2o9m.11193487.0.0.3ac413feY2OZgD#/api?cid=8&path=/order/pack
     */
    public function packOrderItems(array $params = [])
    {
        $orderItems = new \Lazada\Sdk\Api\Response([]);
        $orderItems->setAction(self::ACTION_POST_SET_STATUS_TO_BE_PACKED_BY_MARKET_PLACE);
        try {
            $client = new \Lazada\Sdk\Api\Client($this->config);
            $request = new \Lazada\Sdk\Api\Request('/order/pack');
            $request->addApiParam('shipping_provider', $params['shipping_provider']);
            $request->addApiParam('delivery_type', $params['delivery_type']);
            $request->addApiParam('order_item_ids', $params['order_item_ids']);
            $orderItems = $client->execute($request, $this->config->getAccessToken());
            // $orderItems->load($response);
            // if ($this->config->getDebugMode()) {
            //     $path = $this->getFile(
            //         $this->config->getBaseDirectory(),
            //         self::ACTION_POST_SET_STATUS_TO_BE_PACKED_BY_MARKET_PLACE . '-' .
            //         $this->config->getRegion(). '-'. $this->getSuffix() . '.json'
            //     );
            //     @file_put_contents($path, json_encode($params));
            //     $orderItems->setFeedFile($path);
            // }
        } catch (\Exception $e) {
            if ($this->config->getDebugMode()) {
                $this->config->getLogger()->debug($e->getMessage(), ['path' => __METHOD__]);
            }
        }
        return $orderItems;
    }

    /**
     * Set items to be ready
     * @param array $params
     * @return array|Api\Response
     * @link https://open.lazada.com/doc/api.htm?spm=a2o9m.11193487.0.0.3ac413feY2OZgD#/api?cid=8&path=/order/rts
     */
    public function readyOrderItems(array $params = [])
    {
        $orderItems = new \Lazada\Sdk\Api\Response([]);
        $orderItems->setAction(self::ACTION_POST_SET_STATUS_TO_READY_TO_SHIP);
        try {
            $client = new \Lazada\Sdk\Api\Client($this->config);
            $request = new \Lazada\Sdk\Api\Request('/order/rts');
            $request->addApiParam('tracking_number', $params['tracking_number']);
            $request->addApiParam('shipment_provider', $params['shipment_provider']);
            $request->addApiParam('delivery_type', $params['delivery_type']);
            $request->addApiParam('order_item_ids', $params['order_item_ids']);
            $orderItems = $client->execute($request, $this->config->getAccessToken());
            // $orderItems->load($response);

            // if ($this->config->getDebugMode()) {
            //     $path = $this->getFile(
            //         $this->config->getBaseDirectory(),
            //         self::ACTION_POST_SET_STATUS_TO_READY_TO_SHIP . '-' .
            //         $this->config->getRegion(). '-'. $this->getSuffix() . '.json'
            //     );
            //     @file_put_contents($path, json_encode($params));
            //     $orderItems->setFeedFile($path);
            // }
        } catch (\Exception $e) {
            if ($this->config->getDebugMode()) {
                $this->config->getLogger()->debug($e->getMessage(), ['path' => __METHOD__]);
            }
        }

        return $orderItems;
    }

    /**
     * Get cancel reasons
     * @param bool $force
     * @return Api\Response
     * @link https://open.lazada.com/doc/api.htm?spm=a2o9m.11193487.0.0.3ac413feY2OZgD#/api?cid=8&path=/order/failure_reason/get
     */
    public function getCancelReasons($force = false)
    {
        $reasons = new \Lazada\Sdk\Api\Response([]);
        $reasons->setAction(self::ACTION_GET_CANCEL_ORDER_ITEM_REASONS);
        try {
            // $dir = $this->config->getBaseDirectory() . DS . 'order';
            // $name = self::ACTION_GET_CANCEL_ORDER_ITEM_REASONS . ".json";
            // $path = $dir . DS . $name;
            // if (file_exists($path) && !$force) {
            //     $reasons->setStatus(\Lazada\Sdk\Api\Response::REQUEST_STATUS_SUCCESS);
            //     $reasons->setBody(json_decode(file_get_contents($path), true));
            // } else {
                $client = new \Lazada\Sdk\Api\Client($this->config);
                $request = new \Lazada\Sdk\Api\Request('/order/failure_reason/get', 'GET');
                $response = $client->execute($request, $this->config->getAccessToken());
                // $reasons->load($response);

                // if (!empty($reasons->getBody()) and
                //     $reasons->getStatus() == \Lazada\Sdk\Api\Response::REQUEST_STATUS_SUCCESS
                // ) {
                //     file_put_contents($this->getFile($dir, $name), json_encode($reasons->getBody()));
                // }
            //}
        } catch (\Exception $e) {
            if ($this->config->getDebugMode()) {
                $this->config->getLogger()->debug($e->getMessage(), ['path' => __METHOD__]);
            }
        }

        return $response;
    }

    /**
     * Get shipment providers
     * @param bool $force
     * @return Api\Response
     * @link https://open.lazada.com/doc/api.htm?spm=a2o9m.11193487.0.0.3ac413feY2OZgD#/api?cid=6&path=/shipment/providers/get
     */
    public function getShipmentProviders($force = false)
    {
        $providers = new \Lazada\Sdk\Api\Response([]);
        $providers->setAction(self::ACTION_GET_SHIPMENT_PROVIDERS);
        try {
            // $dir = $this->config->getBaseDirectory() . DS . 'order';
            // $name = self::ACTION_GET_SHIPMENT_PROVIDERS . ".json";
            // $path = $dir . DS . $name;
            // if (file_exists($path) && !$force) {
            //     $providers->setStatus(\Lazada\Sdk\Api\Response::REQUEST_STATUS_SUCCESS);
            //     $providers->setBody(json_decode(file_get_contents($path), true));
            // } else {
                $client = new \Lazada\Sdk\Api\Client($this->config);
                $request = new \Lazada\Sdk\Api\Request('/shipment/providers/get', 'GET');
                $providers = $client->execute($request, $this->config->getAccessToken());
                // $providers->load($response);

                // if (!empty($providers->getBody()) and
                //     $providers->getStatus() == \Lazada\Sdk\Api\Response::REQUEST_STATUS_SUCCESS
                // ) {
                //     file_put_contents($this->getFile($dir, $name), json_encode($providers->getBody()));
                // }
            //}
        } catch (\Exception $e) {
            if ($this->config->getDebugMode()) {
                $this->config->getLogger()->debug($e->getMessage(), ['path' => __METHOD__]);
            }
        }

        return $providers;
    }

}
