<?php

require_once DIR_SYSTEM . "library/lazada-sdk/Autoloader.php";

class LazadaImporter
{
    private static $instance;
    private $db;
    private $session;
    private $config;
    private $currency;
    private $request;
    private $weight;

    /**
     * @param  object $registry Registry Object
     */
    public function __construct($registry)
    {
        $this->db = $registry->get('db');
        $this->session = $registry->get('session');
        $this->config = $registry->get('config');
        $this->currency = $registry->get('currency');
        $this->request = $registry->get('request');
        $this->weight = $registry->get('weight');
    }

    /**
     * @param  object $registry Registry Object
     */
    public static function getInstance($registry)
    {
        if (is_null(static::$instance)) {
            static::$instance = new static($registry);
        }

        return static::$instance;
    }

    public function isEnabled()
    {
        $flag = false;
        if ($this->config->get('lazada_importer_status')) {
            $flag = true;
            $this->_init();
        }
        return $flag;
    }

    public function isInstalled()
    {
        if ($this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "lazada_importer_settings'")->num_rows) {
            return true;
        } else {
            return false;
        }
    }

    public function install()
    {
        $lazada_importer_settings = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "lazada_importer_settings` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `filter` text COLLATE utf8_unicode_ci NOT NULL,
          `search` text COLLATE utf8_unicode_ci NOT NULL,   
          `search_data` longtext COLLATE utf8_unicode_ci NOT NULL,  
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($lazada_importer_settings);
        if ($created)
            $this->log("lazada_importer_settings table created", 6, true);

        $lazada_product_importer = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "lazada_product_importer` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `status` text COLLATE utf8_unicode_ci NOT NULL,
          `type` text COLLATE utf8_unicode_ci NOT NULL, 
          `filter_data` text COLLATE utf8_unicode_ci NOT NULL,  
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($lazada_product_importer);
        if ($created)
            $this->log("lazada_product_importer table created", 6, true);

        $lazada_importer_category = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "lazada_importer_category` (
          `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `category_id` bigint(11) NOT NULL,
          `category_name` text COLLATE utf8_unicode_ci NOT NULL,
          `leaf` int(11) NOT NULL,
          `is_active` int(11) NOT NULL,
          `label` text COLLATE utf8_unicode_ci NOT NULL,
          `region` text COLLATE utf8_unicode_ci NOT NULL,
          `store_category_id` int(10) NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($lazada_importer_category);
        if ($created)
            $this->log("lazada_importer_category table created", 6, true);

        $lazada_importer_product_attribute_combination = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "lazada_importer_product_attribute_combination` (
          `combination_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `product_id` int(11) NOT NULL,
          `lazada_profile_id` int(11) NOT NULL,
          `sku_id` text COLLATE utf8_unicode_ci NOT NULL,
          `combination` text COLLATE utf8_unicode_ci NOT NULL,
          `lazada_item_id` bigint(20) NOT NULL,
          `lazada_status` text COLLATE utf8_unicode_ci NOT NULL,
          `shop_sku` text COLLATE utf8_unicode_ci NOT NULL,
          `lazada_sku_id` text COLLATE utf8_unicode_ci NOT NULL,
          `uploaded_images` longtext COLLATE utf8_unicode_ci NOT NULL,
          `response_data` text COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`combination_id`)
        ) ;";

        $created = $this->db->query($lazada_importer_product_attribute_combination);
        if ($created)
            $this->log("lazada_importer_product_attribute_combination table created", 6, true);
    }

    public function getAccessTokenFromLazada($data = array())
    {
        $UrlConstants = new \Lazada\Sdk\Api\UrlConstants();
        $endPoint = $UrlConstants->getRegionUrl('');

        $config = new \Lazada\Sdk\Api\Config(
            [
                'appSecret' => $data['lazada_importer_app_secret'],
                'appKey' => $data['lazada_importer_app_key'],
                'endpoint' => $endPoint,
                'baseDirectory' => '',
                'debugMode' => false,
                'code' => $data['lazada_importer_app_code'],
            ]
        );

        $api = new \Lazada\Sdk\Api\Api($config);
        $response = $api->getToken();

        if(isset($response['code']) && $response['code'] == '0'){

            foreach($response as $key => $value){

                if($key == 'access_token')
                    $this->editSettingValue('lazada', 'lazada_importer_access_token', $value);
                elseif($key == 'expires_in')
                    $this->editSettingValue('lazada', 'lazada_importer_expires_in', $value);
                elseif($key == 'refresh_token')
                    $this->editSettingValue('lazada', 'lazada_importer_refresh_token', $value);
                elseif($key == 'refresh_expires_in')
                    $this->editSettingValue('lazada', 'lazada_importer_refresh_expires_in', $value);
                elseif($key == 'country')
                    $this->editSettingValue('lazada', 'lazada_importer_country', $value);
                else
                    CONTINUE;
            }
        }
        return $response;
    }

    public function editSettingValue($code = '', $key = '', $value = '', $store_id = 0) {
        $sql = $this->db->query("SELECT `value` FROM " . DB_PREFIX . "setting WHERE store_id = '" . (int)$store_id . "' AND `code` = '" . $this->db->escape($code) . "' AND `key` = '". $this->db->escape($key) ."' ");
        if ($sql->num_rows) {
            $this->db->query("UPDATE " . DB_PREFIX . "setting SET `value` = '" . $this->db->escape($value) . "' WHERE `code` = '" . $this->db->escape($code) . "' AND `key` = '" . $this->db->escape($key) . "' AND store_id = '" . (int)$store_id . "'");
        } else {
            $this->db->query("INSERT INTO " . DB_PREFIX . "setting SET store_id = '" . (int)$store_id . "', `code` = '" . $this->db->escape($code) . "', `key` = '" . $this->db->escape($key) . "', `value` = '" . $this->db->escape($value) . "'");
        }
    }

    public function getConfigData($result, $key = '')
    {
        $access_token = $result['lazada_importer_access_token'];
        $access_token_expiry = strtotime($result['lazada_importer_expires_in']);
        $refresh_token = $result['lazada_importer_refresh_token'];
        $refresh_token_expiry = strtotime($result['lazada_importer_refresh_expires_in']);

        $baseDirectory = DIR_SYSTEM . 'var/lazada';
        $UrlConstants = new \Lazada\Sdk\Api\UrlConstants();
        $endPoint = $UrlConstants->getRegionUrl($result['lazada_importer_country']);

        $now = strtotime(date('Y-m-d h:i:s a'));

        if(!empty($access_token) && !empty($access_token_expiry) && $access_token_expiry < $now){

            if(!empty($refresh_token_expiry) && $refresh_token_expiry < $now) {

                $config = new \Lazada\Sdk\Api\Config(
                    [
                        'appSecret' => $result['lazada_importer_app_secret'],
                        'appKey' => $result['lazada_importer_app_key'],
                        'endpoint' => $endPoint,
                        'refreshToken' => $refresh_token,
                        'baseDirectory' => '',
                    ]
                );

                $api = new \Lazada\Sdk\Api\Api($config);
                $response = $api->refreshToken();
                if(isset($response['code']) && $response['code'] == '0'){
                    foreach($response as $key => $value){
                        if($key == 'code')
                            $this->editSettingValue('lazada', 'lazada_importer_code', $value);
                        elseif($key == 'access_token')
                            $this->editSettingValue('lazada', 'lazada_importer_access_token', $value);
                        elseif($key == 'expires_in')
                            $this->editSettingValue('lazada', 'lazada_importer_expires_in', $value);
                        elseif($key == 'refresh_token')
                            $this->editSettingValue('lazada', 'lazada_importer_refresh_token', $value);
                        elseif($key == 'refresh_expires_in')
                            $this->editSettingValue('lazada', 'lazada_importer_refresh_expires_in', $value);
                        elseif($key == 'country')
                            $this->editSettingValue('lazada', 'lazada_importer_country', $value);
                        else
                            CONTINUE;
                    }
                }
                $access_token = $response['access_token'];
            } else {
                $json['success'] = false;
                $json['message'] = 'Lazada refresh token has expired. Kindly re-install the app for continuing using the integration services.';
                return $json;
            }
        }

        if($key == 'product'){
            $config = new \Lazada\Sdk\Api\Config(
                [
                    'appSecret' => $result['lazada_importer_app_secret'],
                    'appKey' => $result['lazada_importer_app_key'],
                    'endpoint' => $endPoint,
                    'token' => $access_token,
                    'baseDirectory' => '',
                    'debugMode' => false,
                    'code' => ''
                ]
            );
        } else {
            $config = new \Lazada\Sdk\Api\Config(
                [
                    'appSecret' => $result['lazada_importer_app_secret'],
                    'appKey' => $result['lazada_importer_app_key'],
                    'endpoint' => $endPoint,
                    'baseDirectory' => $baseDirectory,
                    'debugMode' => false,
                    'code' => $result['lazada_importer_app_code']
                ]
            );

        }


        return $config;
    }

    public function prepareProductData($filter_data, $products = array(), $import_setting_data = array())
    {
        //echo '<pre>'; echo count($products); print_r($products); die;
        $product_id = false;
        if(isset($products) && is_array($products)){
            try {
                if ($filter_data == '0') // No filter selected
                {
                    $date_available = $this->config->get('lazada_importer_available_date');
                    $tax_class_id = $this->config->get('lazada_importer_tax_class_id');
                    $length_class_id = $this->config->get('lazada_importer_length_class_id');
                    $weight_class_id = $this->config->get('lazada_importer_weight_class_id');
                    $category[] = $this->config->get('lazada_importer_product_category');
                    $store[] = $this->config->get('lazada_importer_product_store');

                    if ($this->config->get('lazada_importer_field_mapping')) {
                        foreach ($this->config->get('lazada_importer_field_mapping') as $key => $value) {
                            $data[$key] = $value;
                        }
                    }
                } else {
                    $date_available = $import_setting_data['available_date'];
                    $tax_class_id = $import_setting_data['tax_class_id'];
                    $length_class_id = $import_setting_data['length_class_id'];
                    $weight_class_id = $import_setting_data['weight_class_id'];
                    $category[] = isset($import_setting_data['product_category']) ? $import_setting_data['product_category'] : array();
                    $store[] = $import_setting_data['product_store'];

                    if ($import_setting_data['field_mapping']) {
                        foreach ($import_setting_data['field_mapping'] as $key => $value) {
                            $data[$key] = $value;
                        }
                    }
                }

                if(empty($date_available))
                    $date_available = date('Y-m-d h:i:s a');
                if(empty($tax_class_id))
                    $tax_class_id = '9';
                if(empty($length_class_id))
                    $length_class_id = '3';
                if(empty($weight_class_id))
                    $weight_class_id = '1';

                 $json = array();
                foreach ($products as $key => $product) 
                {
                    $item_id = $product['item_id'];
                    $category_id = $product['primary_category'];
                    $productData = $product['attributes'];
                    $ProductDataArray = array();
                    foreach ($productData as $key => $product_data) {
                        foreach ($data as $index => $value) {
                            if ($key == $index)
                                $ProductDataArray[$index] = $product_data;
                        }
                    }

                if (!isset($ProductDataArray['name']) && empty($ProductDataArray['name']))
                        $ProductDataArray['name'] = $productData['name'];

                $existingProduct = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_description` WHERE `name` = '" . $this->db->escape($ProductDataArray['name']) . "'");

                if ($existingProduct->num_rows == 0) {

                    $language_id = $this->config->get('config_language_id');
                    if(empty($language_id))
                        $language_id = '1';
                    $store_id = $this->config->get('config_store_id');
                    if(empty($store_id))
                        $store_id = '0';

                    $price_array = array();
                    $quantity = '0';
                    $specialPrice_array = array();
                    $options = array();
                    $product_option = array();
                    $product_option_value = array();
                    $response_data = array();
                    $images = array();
                     $img = array();
                    if (isset($productData['Images']) && !empty($productData['Images']))
                        $img = $this->saveImages($productData['Images'], $productData['name']);
                    $sort_order = '1';
                    foreach ($product['skus'] as $configurableProduct) {

                        if (isset($configurableProduct['price']) && !empty($configurableProduct['price']))
                            $price_array[] = $configurableProduct['price'];
                        if (isset($configurableProduct['quantity']) && !empty($configurableProduct['quantity']))
                            $quantity += $configurableProduct['quantity'];
                        if (isset($configurableProduct['special_price']) && !empty($configurableProduct['special_price'])){
                            $specialPrice_array[] = $configurableProduct['special_price'];
                            $price_difference = $configurableProduct['price'] - $configurableProduct['special_price'];
                            $price_prefix = '-';
                        }
                        if(isset($productData['name']) && !empty($productData['name']))
                          $productData['name'] = $productData['name'];
                        else
                         $productData['name'] = '';

                        if(isset($configurableProduct['Images']) && !empty($configurableProduct['Images'])){
                        $configImages = array();
                        foreach($configurableProduct['Images'] as $imgKey => $imgVal){
                           $imgVal = trim($imgVal);
                             if(empty($imgVal))
                               CONTINUE;
                             else
                              $configImages[$imgKey] = html_entity_decode($imgVal);
                        }
                        
                            if(!empty($configImages)){
                               $optionImage = $this->saveImages($configImages, $productData['name']);
                               $images = array_merge($optionImage, $img);
                            }
                         }

                        if(isset($configurableProduct['color_family']) && !empty($configurableProduct['color_family'])
                            || isset($configurableProduct['size']) && !empty($configurableProduct['size']))
                        {
                            if(isset($configurableProduct['color_family'])) {
                                $type = 'select';
                                $name = $configurableProduct['color_family'];
                                $option_name = 'Select';
                                $sortOrder = '1';
                            } elseif (isset($configurableProduct['size'])){
                                $type = 'radio';
                                $name = $configurableProduct['size'];
                                $option_name = 'Radio';
                                $sortOrder = '2';
                            } else {
                                $type = '';
                                $name = '';
                            }

                            $optionExist = $this->db->query("SELECT `option_id` FROM `". DB_PREFIX."option_description` WHERE `name` = '". $this->db->escape($option_name) ."' AND language_id = '" . (int)$language_id .
                                    "' ");

                            if ($optionExist->num_rows == 0) {
                                $this->db->query("INSERT INTO `" . DB_PREFIX . "option` SET type = '". $this->db->escape($type) ."', sort_order = '". (int)$sortOrder ."' ");
                                $option_id = $this->db->getLastId();
                                $this->db->query("INSERT INTO `" . DB_PREFIX . "option_description` SET option_id = '" . (int)$option_id .
                                    "', language_id = '" . (int)$language_id .
                                    "', name = '" . $this->db->escape($option_name) . "'");
                            } else {
                                $option_id = $optionExist->row['option_id'];
                            }

                            if(isset($option_id) && !empty($option_id)){
                                $sql = $this->db->query("SELECT `name` FROM `". DB_PREFIX."option_value_description` WHERE `option_id` = '". (int)$option_id ."' AND `language_id` = '". (int)$language_id ."' AND `name` = '". $this->db->escape($name) ."' ");
                                if($sql->num_rows){
                                    $result = $sql->rows;
                                
                                    $option_value = '';
                                    foreach($result as $k => $v){
                                        $option_value .= $v['name'] . ',';
                                    }

                                    if(isset($name) && is_array($option_value) && !in_array($name, $option_value))
                                    {

                                        $this->db->query("INSERT INTO `". DB_PREFIX."option_value` SET `option_id` = '". (int)$option_id ."', `image` = '', `sort_order` = '". $sort_order ."' ");

                                        $option_value_id = $this->db->getLastId();

                                        $this->db->query("INSERT INTO `". DB_PREFIX."option_value_description` SET `option_value_id` = '". (int)$option_value_id ."', `option_id` = '". (int)$option_id ."', `language_id` = '". (int)$language_id ."', `name` = '". $this->db->escape($name) ."' ");

                                    $sort_order++;
                                    } else {
                                            $sql = $this->db->query("SELECT `option_value_id` FROM `". DB_PREFIX."option_value_description` WHERE `option_id` = '". (int)$option_id ."' AND `language_id` = '". (int)$language_id ."' AND `name` = '". $this->db->escape($name) ."' ");
                                            $option_value_id = $sql->row['option_value_id'];
                                    }
                                } else {
                                    $this->db->query("INSERT INTO `". DB_PREFIX."option_value` SET `option_id` = '". (int)$option_id ."', `image` = '', `sort_order` = '". $sort_order ."' ");

                                    $option_value_id = $this->db->getLastId();

                                    $this->db->query("INSERT INTO `". DB_PREFIX."option_value_description` SET `option_value_id` = '". (int)$option_value_id ."', `option_id` = '". (int)$option_id ."', `language_id` = '". (int)$language_id ."', `name` = '". $this->db->escape($name) ."' ");
                                    $sort_order++;
                                }
                            }
                            //$option_value_id = isset($option_value_id) ? $option_value_id : $configurableProduct['SellerSku'];
                            $option_value_id = isset($option_value_id) ? $option_value_id : '0';
                            $product_option_value[] = array(
                                'option_value_id' => $option_value_id,
                                'name' => $name,
                                'quantity' => $configurableProduct['quantity'],
                                'subtract' => '1',
                                'price' => isset($price_difference) ? $price_difference : $configurableProduct['price'],
                                'price_prefix' => isset($price_prefix) ? $price_prefix : '+',
                                'points' => '0',
                                'points_prefix' => '+',
                                'weight' => $configurableProduct['package_weight'],
                                'weight_prefix' => '+'
                            );

                            if($option_id && isset($product_option[$option_id]) && isset($product_option[$option_id]['type'])) {
                                $product_option[$option_id]['product_option_value'] =  $product_option_value;
                            } else if($option_id){
                                $product_option[$option_id] = array(
                                    'type' => $type,
                                    'option_id' => $option_id,
                                    'required' => '1',
                                    'product_option_value' => $product_option_value,
                                );
                            }

                            $response_data[] = array(
                               'sku_id' => isset($configurableProduct['SellerSku']) ? $configurableProduct['SellerSku'] : '',
                               'combination' => array(
                                $option_value_id => isset($name) ? $name : '',
                                ),
                               'lazada_item_id' => isset($item_id) ? $item_id : '',
                               'lazada_status' => isset($configurableProduct['Status']) ? $configurableProduct['Status'] : '',
                               'shop_sku' => isset($configurableProduct['ShopSku']) ? $configurableProduct['ShopSku'] : '',
                               'lazada_sku_id' => isset($configurableProduct['SkuId']) ? $configurableProduct['SkuId'] : '',
                               'uploaded_images' => isset($configurableProduct['Images']) ? html_entity_decode($configurableProduct['Images']) : '',
                               'response_data' => isset($configurableProduct) ? $configurableProduct : array()
                             );
                        }
                        
                    }

                    $options[] = array(
                        'product_option' => $product_option,
                    );
                  //echo '<pre>'; print_r($options); die;
                    if(!empty($price_array))
                        $price = min($price_array);
                    else
                        $price = '0.0';
                    if(!empty($specialPrice_array))
                        $special_price = min($specialPrice_array);
                    else
                        $special_price = '0.0';

                    if (!isset($ProductDataArray['short_description']) && empty($ProductDataArray['short_description']))
                        $ProductDataArray['short_description'] = $productData['short_description'];
                    if (!isset($ProductDataArray['brand']) && empty($ProductDataArray['brand']))
                        $ProductDataArray['brand'] = $productData['brand'];
                    if (!isset($ProductDataArray['description']) && empty($ProductDataArray['description']))
                        $ProductDataArray['description'] = isset($productData['description']) ? $productData['description'] : '';

                    if(isset($productData['model']))
                        $model = $productData['model'];
                    else
                        $model = '';

                        $manufacturer_query = $this->db->query("SELECT m.`manufacturer_id` FROM `" . DB_PREFIX . "manufacturer` AS m LEFT JOIN `" . DB_PREFIX . "manufacturer_to_store` AS mts ON (m.manufacturer_id = mts.manufacturer_id) WHERE m.`name` = '" . $this->db->escape($ProductDataArray['brand']) . "' AND mts.`store_id` = '" . $store_id . "' ");
                        if ($manufacturer_query->num_rows)
                            $manufacturer_id = $manufacturer_query->row['manufacturer_id'];
                        else
                            $manufacturer_id = '0';

                        $this->db->query("INSERT INTO `" . DB_PREFIX . "product` SET model = '" . $this->db->escape($model) . "', 
                        quantity = '" . (int)$quantity . "', 
                        date_available = '". $date_available ."', 
                        manufacturer_id = '" . (int)$manufacturer_id . "', 
                        price = '" . (float)$price . "', 
                        stock_status_id = '" . 7 . "', 
                        length_class_id = '" . (int)$length_class_id . "', 
                        weight_class_id = '". (int)$weight_class_id ."',
                        status = '" . 1 . "', 
                        tax_class_id = '" . (int)$tax_class_id . "', 
                        sort_order = '" . 1 . "', 
                        date_added = NOW()");

                        $product_id = $this->db->getLastId();

                        if (!empty($category_id)) {
                            $this->db->query("INSERT INTO " . DB_PREFIX . "product_to_category SET product_id = '" . (int)$product_id . "', category_id = '" . (int)$category_id . "'");
                        } elseif(is_array($category) && !empty($category)) {
                                 foreach($category as $key => $category_id)
                                 {
                                   $this->db->query("INSERT INTO " . DB_PREFIX . "product_to_category SET product_id = '" . (int)$product_id . "', category_id = '" . (int)$category_id . "'");
                                }
                        }

                        $this->db->query("INSERT INTO " . DB_PREFIX . "product_to_store SET product_id = '" . (int)$product_id . "', store_id = '" . (int)0 . "'");

                        $this->db->query("INSERT INTO `" . DB_PREFIX . "product_description` SET product_id = '" . (int)$product_id . "',
                         language_id = '" . (int)$language_id . "', 
                         name = '" . $this->db->escape($ProductDataArray['name']) . "', 
                         description = '" . $this->db->escape($ProductDataArray['description']) . "', 
                         tag = '', 
                         meta_description = '". $this->db->escape($ProductDataArray['short_description']) ."', 
                         meta_keyword = '', 
                         meta_title = '' ");
                         
                         if (isset($images[0]) && $images[0] && file_exists(DIR_IMAGE.$images[0])) 
                         {
                            $this->db->query("UPDATE `" . DB_PREFIX . "product` SET image = '" . $this->db->escape(html_entity_decode($images[0])) . "' WHERE product_id = '" . (int)$product_id . "'");
                        }

                        if (isset($images) && !empty($images) && is_array($images)) {
                            $sort_order = '1';
                            foreach ($images as $image) {
                               if($image && file_exists(DIR_IMAGE.$image)){
                                  $this->db->query("INSERT INTO `" . DB_PREFIX . "product_image` SET product_id = '" . (int)$product_id .
                                    "', sort_order = '". (int)$sort_order ."', image = '" . $this->db->escape(html_entity_decode($image)) . "'");
                                }
                                $sort_order++;
                            }
                        }

                        if (!empty($options) && is_array($options)) {
                            foreach($options as $key => $data){
                                foreach ($data['product_option'] as $product_option) {
                                    //$product_option = $data['product_option'];
                                    if ($product_option['type'] == 'select' || $product_option['type'] == 'radio') {
                                        if (isset($product_option['product_option_value'])) {
                                            $this->db->query("INSERT INTO " . DB_PREFIX . "product_option SET product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option['option_id'] . "', required = '" . (int)$product_option['required'] . "'");
                                            $product_option_id = $this->db->getLastId();
                                            foreach ($product_option['product_option_value'] as $product_option_value) {
                                                $this->db->query("INSERT INTO " . DB_PREFIX . "product_option_value SET product_option_id = '" . (int)$product_option_id . "', product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option['option_id'] . "', option_value_id = '" . (int)$product_option_value['option_value_id'] . "', quantity = '" . (int)$product_option_value['quantity'] . "', subtract = '" . (int)$product_option_value['subtract'] . "', price = '" . (float)$product_option_value['price'] . "', price_prefix = '" . $this->db->escape($product_option_value['price_prefix']) . "', points = '" . (int)$product_option_value['points'] . "', points_prefix = '" . $this->db->escape($product_option_value['points_prefix']) . "', weight = '" . (float)$product_option_value['weight'] . "', weight_prefix = '" . $this->db->escape($product_option_value['weight_prefix']) . "'");
                                            }
                                        }
                                    } else {
                                        $this->db->query("INSERT INTO " . DB_PREFIX . "product_option SET product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option['option_id'] . "', value = '', required = '" . (int)$product_option['required'] . "'");
                                    }
                                }
                            }
                        }

                        if(!empty($product_id) && !empty($response_data) && is_array($response_data))
                        {
                            foreach($response_data as $key => $value){
                                $combinationExist = $this->db->query("SELECT * FROM `". DB_PREFIX ."lazada_importer_product_attribute_combination` WHERE `sku_id` = '". $this->db->escape($value['sku_id']) ."' ");
                                if($combinationExist->num_rows){
                                    $this->db->query("UPDATE `". DB_PREFIX ."lazada_importer_product_attribute_combination` SET `product_id` = '". (int)$product_id ."', `lazada_profile_id` = '0', `sku_id` = '". $this->db->escape($value['sku_id']) ."', `combination` = '". $this->db->escape(json_encode($value['combination'])) ."', `lazada_item_id` = '". $this->db->escape($value['lazada_item_id']) ."', `lazada_status` = '". $this->db->escape($value['lazada_status']) ."', `shop_sku` = '". $this->db->escape($value['shop_sku']) ."', `lazada_sku_id` = '". $this->db->escape($value['lazada_sku_id']) ."', `uploaded_images` = '". $this->db->escape(json_encode($value['uploaded_images'])) ."', `response_data` = '". $this->db->escape(json_encode($value['response_data'])) ."' WHERE `sku_id` = '". $this->db->escape($value['sku_id']) ."' ");
                                } else {
                                    $this->db->query("INSERT INTO `". DB_PREFIX ."lazada_importer_product_attribute_combination` SET `product_id` = '". (int)$product_id ."', `lazada_profile_id` = '0', `sku_id` = '". $this->db->escape($value['sku_id']) ."', `combination` = '". $this->db->escape(json_encode($value['combination'])) ."', `lazada_item_id` = '". $this->db->escape($value['lazada_item_id']) ."', `lazada_status` = '". $this->db->escape($value['lazada_status']) ."', `shop_sku` = '". $this->db->escape($value['shop_sku']) ."', `lazada_sku_id` = '". $this->db->escape($value['lazada_sku_id']) ."', `uploaded_images` = '". $this->db->escape(json_encode($value['uploaded_images'])) ."', `response_data` = '". $this->db->escape(json_encode($value['response_data'])) ."' ");
                                }
                            }
                        }

                    } // existingProduct if ends here

                    if(!empty($product_id))
                        $json = array('success' => true, 'message' => 'Products Fetched Successfully!');
                    else
                        $json = array('success' => false, 'message' => 'Product(s) already imported!');

                } // foreach product ends here
            } catch(\Exception $exception){
                //print_r($exception->getMessage());die;
                $log = new Log('lazada_importer_product.log');
                $log->write($exception->getMessage());
            }
        }
        return $json;
    }

    public function saveImages($data, $productName = 'alt_prod')
    {
        $imgPaths = array();
        try {
        foreach ($data as $img) {
           $fileInfo = pathinfo($img);
           $productName = preg_replace('/[^a-zA-Z0-9\']/', '_', $productName);
           $productName = filter_var(strtolower($productName), FILTER_SANITIZE_STRING) . '.' . (isset($fileInfo['extension']) ? strtok($fileInfo['extension'], '?') : 'jpg');
           $name = 'product_image_' . str_replace('/', '_', $productName);
           $name = str_replace("'", '_', $name);
           $ch = curl_init($img);
           $fileName = 'catalog/demo/' . $name;
           if (!file_exists(DIR_IMAGE.$fileName)) {
              $fp = fopen(DIR_IMAGE . $fileName, 'wb');
              curl_setopt($ch, CURLOPT_FILE, $fp);
              curl_setopt($ch, CURLOPT_HEADER, 0);
              $response = curl_exec($ch);

              if ($response == true) {
                 $imgPaths[] = html_entity_decode($fileName);
              }
              curl_close($ch);
              fclose($fp);
           } else {
              $imgPaths[] = html_entity_decode($fileName);
           }
         }
        } catch (\Exception $exception) {
            $log = new Log('image_saving.log');
            $log->write($exception->getMessage());
        }
        return $imgPaths;
    }
}
